import java.util.ArrayList;
public class EntityEquip
{
    private Armor armorHead;
    private Armor armorBelly;
    private Armor armorLegs;
    private Armor armorFeets;
    private Weapon weapon1;
    private Weapon weapon2;
    private Weapon weapon3;
    private Weapon weapon4;
    private ArrayList<ItemStack> items = new ArrayList<>();

    public EntityEquip(){

    }

    public EntityEquip(Armor pHead, Armor pBelly, Armor pLegs, Armor pFeets, Weapon p1, Weapon p2, Weapon p3, Weapon p4, ArrayList<ItemStack> pItems){
        armorHead = pHead;
        armorBelly = pBelly;
        armorLegs = pLegs;
        armorFeets = pFeets;
        weapon1 = p1;
        weapon2 = p2;
        weapon3 = p3;
        weapon4 = p4;
        items = pItems;
    }
    
    public ArrayList<Armor> getArmor(){
        ArrayList<Armor> armor = new ArrayList<>();
        armor.add(armorHead);
        armor.add(armorBelly);
        armor.add(armorLegs);
        armor.add(armorFeets);
        return armor;
    }
    
    public ArrayList<Weapon> getWeapons(){
        ArrayList<Weapon> weapons = new ArrayList<>();
        weapons.add(weapon1);
        weapons.add(weapon2);
        weapons.add(weapon3);
        weapons.add(weapon4);
        return weapons;
    }

    public ArrayList<ItemStack> getItems(){
        return items;
    }

    public EntityEquip setItems(ArrayList<ItemStack> pItems){
        items = pItems;
        return this;
    }

    public EntityEquip addItem(ItemStack item){
        items.add(item);
        return this;
    }
    
    public void setArmor(String position, Armor pArmor){
        switch (position){
            case "head":
                armorHead = pArmor;
                break;
            case "belly":
                armorBelly = pArmor;
                break;
            case "legs":
                armorLegs = pArmor;
                break;
            case "feets":
                armorFeets = pArmor;
                break;
        }
    }

    public void setWeapon(int slot, Weapon pWeapon){
        switch (slot){
            case 1:
                weapon1 = pWeapon;
                System.out.println("Eins");
                break;
            case 2:
                weapon2 = pWeapon;
                System.out.println("Zwei");
                break;
            case 3:
                weapon3 = pWeapon;
                break;
            case 4: 
                weapon4 = pWeapon;
                break;
            }   
    }

    public boolean addWeapon(Weapon pWeapon){
        if (weapon1 == null){
            weapon1 = pWeapon;
            System.out.println("Waffenslot 1 belegt");
            return true;
        }else {
            if (weapon2 == null) {
                weapon2 = pWeapon;
                return true;
            } else {
                if (weapon3 == null) {
                    weapon3 = pWeapon;
                    return true;
                } else {
                    if (weapon4 == null) {
                        weapon4 = pWeapon;
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
