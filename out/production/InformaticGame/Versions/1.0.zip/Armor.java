public class Armor{
    
    private String position;
    private String name;
    private Material material;
    private float durability = 1;
    
    public Armor(String pName, String pPosition, Material pMaterial){
       name = pName;
       position = pPosition;
       material = pMaterial;
    }
    
    public String getName(){
        return name;
    }
    
    public String getPosition(){
        return position;
    }
    
    public Material getMaterial(){
        return material;
    }
    
    public float getDurability(){
        return durability;
    }
    
    public void setName(String pName){
        name = pName;
    }
    
    public void setPosition(String pPosition){
        position = pPosition;
    }
    
    public void setMaterial(Material pMaterial){
        material = pMaterial;
    }
    
    public void setDurability(float pDurability){
        durability = pDurability;
    }
}
