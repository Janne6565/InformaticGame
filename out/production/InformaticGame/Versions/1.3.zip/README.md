# Informatik Spiel

# Erstellt von: Janne Keipert

Das User Interface basiert nur auf Ascii Schriftzeichen.

Dieses Spiel wurde in wegen einer Informatik Aufgabe  programmiert.
