public class Main { // Main (Nur zum Testem)
    public static void main(String[] args) throws InterruptedException {
        new Kampfregel();
    }
}
