# Informatik Spiel

# Erstellt von: Janne Keipert

Das User Interface basiert nur auf Ascii Schriftzeichen.

Dieses Spiel wurde in wegen einer Informatik Aufgabe  programmiert.

# Changelog: 

1.3:
  - Shopsystem
  - Verbesserung des Kampfsystems:
    - Unbegrenzte Waffenslots
    - Waffen können kaputt gehen:
      - Wenn eine Waffe kaputt geht, wird 5 Schrott fallengelassen
  - Neue Monster:
    - Spinne: 
      - Loot: 1-3 Fäden
      - Leben: 25
      - Waffe: Peitsche
  - Neue Waffen:
    - Sense:  
      - Schaden: 20
      - Haltbarkeit: 100
      - Stärke: 60%
    - Messer:
      - Schaden: 10
      - Haltbarkeit: 100
      - Stärke: 1%
    - Peitsche:
      - Schaden: 15
      - Haltbarkeit: 5
      - Stärke: 2%
  - Neue Items:
    - Schrott:
      - Wert: 1€

1.2:
  - Verbesserung des Kampfsystem
 
1.1: 
  - Verbesserung des Kampfsystems:
      

1.0:
  - Grundlagen des Spieles
  - "Tutorial" Eingebunden
  - Grundlagendes Kampfsystems (Begrenzt auf 5 Waffenslots)
  - Neue Monster: 
    - Alter Zombie
      - Loot: 2 Verrotetes Fleisch
      - Leben: 20 
      - Waffe: Stock
    - Skelett:
      - Loot: 1-3 Knochen
      - Leben: 20
      - Waffe: Lang Schwert
  - Neue Waffen: 
    - Alter Dolch:
      - Schaden: 5
      - Haltbarkeit: 5
      - Stärke: 20%
    - Stock:
      - Schaden: 1
      - Haltbarkeit: 10
      - Stärke: 2%
    - Lang Schwert:
      - Schaden: 10
      - Haltbarkeit: 25
      - Stärke: 40%
  - Neue Items:
    - Verrotetes Fleisch: 
      - Wert: 1€
    - Knochen: 
      - Wert: 5€
    - Faden: 
      - Wert: 20€
