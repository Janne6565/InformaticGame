import java.util.ArrayList;

public class LibaryMonsters {
    public static Monster oldZombie;
    public static Monster skelleton;
    private static Wuerfel wuerfel = new Wuerfel(1, 3);
    private static ArrayList<Monster> monster = new ArrayList<>();
    public LibaryMonsters(){
        EntityEquip equipOldZombie = new EntityEquip(null, null, new Armor("Alte Lederhose", "legs", new Material("Leder", 1)), null, LibaryWeapons.stick,null, null, null, null);
        ArrayList<String> skinOldZombie = new ArrayList<>();
        skinOldZombie.add("  _____                      ");
        skinOldZombie.add("  |* *|                      ");
        skinOldZombie.add("  |___|                      ");
        skinOldZombie.add("   _||_                      ");
        skinOldZombie.add("  |    |                     ");
        skinOldZombie.add("--|    |--                   ");
        skinOldZombie.add("  |    |                     ");
        skinOldZombie.add("  |    |                     ");
        skinOldZombie.add("  |____|                     ");
        skinOldZombie.add("   ||||                      ");
        skinOldZombie.add("   ||||                      ");
        Loot lootOldZombie = new Loot();
        LibaryItems items = new LibaryItems();
        lootOldZombie.getDrops().add(items.rottenFlash.setCount(wuerfel.wuerfeln()));
        oldZombie = new Monster("Alter Zombie", "Nahkampf", 1, 20, equipOldZombie, skinOldZombie, lootOldZombie);
        oldZombie.setHealth(5);
        monster.add(oldZombie);

        EntityEquip equipSkelleton = new EntityEquip(null, null, null, null, LibaryWeapons.longSword,null, null, null, null);
        ArrayList<String> skinSkelleton = new ArrayList<>();
        skinSkelleton.add("    _______                      ");
        skinSkelleton.add("    | x x |                      ");
        skinSkelleton.add("    | __  |                      ");
        skinSkelleton.add("    |_____|                      ");
        skinSkelleton.add("     __||__                     ");
        skinSkelleton.add("   || o  x ||                      ");
        skinSkelleton.add("  | | -  | | |                    ");
        skinSkelleton.add(" |  ||     |  |                   ");
        skinSkelleton.add(" |  | -  o |  |                   ");
        skinSkelleton.add("    |  | - |                      ");
        skinSkelleton.add("    |______|                      ");
        skinSkelleton.add("     | || |                      ");
        skinSkelleton.add("     | || |                      ");
        skinSkelleton.add("     | || |                      ");
        Loot lootSkelleton = new Loot();
        lootSkelleton.getDrops().add(items.bone.setCount(wuerfel.wuerfeln()));
        skelleton = new Monster("Skellet", "Nahkampf", 1, 20, equipSkelleton, skinSkelleton, lootSkelleton);
        monster.add(skelleton);
    }

    public static Monster getRandomMonster(int level){
        wuerfel.setMax(monster.size()-1);
        wuerfel.setMin(0);
        return monster.get(wuerfel.wuerfeln());
    }
}
